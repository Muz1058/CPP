#include<iostream>
using namespace std;
int main()
{
	int num;
	cout << "Enter a number:";
	cin >> num;
	cout << "digit of the number are:";
	int reverse;
	while (num % 10 > 0)
	{
		reverse = num % 10;
		if (num < 10)
		{
			cout << " and ";
		}
		cout << reverse;
	    if (num/10>=10 )
		{
			cout << ",";
		}
		num = num / 10;
	}

	
	return 0;
}