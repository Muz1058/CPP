#include<iostream>
using namespace std;
int main()
{
	int num, reverse;
	cout << "Enter a number:";
	cin >> num;
	while (num % 10 > 0)
	{
		reverse = num % 10;
		cout << reverse ;
		num =num/10;
	}

	return 0;
}