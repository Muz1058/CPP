#include<iostream>
using namespace std;
int main()
{
	int num;
	cout << "Enter a number:";
	cin >> num;
	cout << "digit of the number are:";
	int reverse, digitsum=0;
	while (num % 10 > 0)
	{
		reverse = num % 10;
		if (num < 10)
		{
			cout << " and ";
		}
		cout << reverse;
		if (num / 10 >= 10)
		{
			cout << ",";
		}
		digitsum += reverse;
		num = num / 10;
	}
	cout << "\nSum of the digits of the number= " << digitsum;

	return 0;
}