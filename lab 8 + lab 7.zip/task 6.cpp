#include<iostream>
using namespace std;
int main()
{
	int num, reverse, digit_square, square_sum=0;
	cout << "Number is :";
	cin >> num;
	
	while (num % 10 > 0)
	{
		reverse = num % 10;
		cout << "Digit is " << reverse << " its square is " << reverse * reverse << endl;
		square_sum += reverse * reverse;
		num /= 10;
	}
	cout << "Square sum is " << square_sum << endl;





	return 0;
}