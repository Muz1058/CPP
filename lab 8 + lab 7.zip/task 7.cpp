#include<iostream>
using namespace std;
int main()
{
	int num;
	cout << "Enter a number:";
	cin >> num;
	int temp = num;
	int reverse=0;
	cout << "Number is " << num << " its reverse number is ";
	while (temp % 10 > 0)
	{
		reverse = temp%10;
		cout<< reverse;

		temp /= 10;
	}
	
	return 0;
}