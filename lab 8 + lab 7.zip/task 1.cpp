#include<iostream>
using namespace std;
int main()
{
	int x;
	cout << "Enter a number:";
	cin >> x;
	int num1 = x;
	while (num1 > 0)
	{
		cout << num1 << endl;
		--num1;
	}
	int num2 = 0;
	while (num2 <= x)
	{
		cout << num2 << endl;
		++num2;
	}
	return 0;
}
