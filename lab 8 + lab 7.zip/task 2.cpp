#include<iostream>
using namespace std;
int main()
{
	int x, y;
	cout << "Enter first number:";
	cin >> x;
	cout << "Enter second number:";
	cin >> y;
	if (x > y)
	{
		swap(x, y);
	}
	cout << "Number between " << x << " and " << y << " which are divisible by 3 or 5 =\n";
	int num =1;
	while (num <= y)
	{
		if (num % 3 == 0 || num % 5 == 0)
		{
			cout << num << endl;
		}
		++num;
	}

	return 0;
}