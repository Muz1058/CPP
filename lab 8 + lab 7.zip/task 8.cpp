#include <iostream>
using namespace std;
int main()
{
	int x, fact=1;
	cout << "Enter a number: ";
	cin >> x;
	int num = x;
	cout << "\n factorial of [";
	while (num > 0)
	{
		
		cout << num;
		if (num > 1)
		{
			cout << "*";
		}
	 
		fact *= num;
		num--;

	}
 cout<< "] is = " << fact;

	







	return 0;
}