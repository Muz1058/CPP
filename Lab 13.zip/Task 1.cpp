#include<iostream>
using namespace std;
int main()
{
	int arr[7] = { 1,2,3,6,5,4 };
	int arr2[7];
	int count = 1;
	for (int i = 0; i < 6; i++)
	{
		arr2[count] = arr[i];
		count++;
	}
	for (int j = 0; j < 7; j++)
		arr[j] = arr2[j];
	for (int k = 0; k < 7; k++)
		cout << arr[k] << endl;
	return 0;
}