#include<iostream>
using namespace std;
int main()
{
	int arr[10] = { 5,6,7,5,9,10,58,5,5,66 };
	int num, replace, found = 0;
	cout << "Enter number you want to found :";
	cin >> num;
	cout << "Enter your desired Number for replacement :";
	cin >> replace;
	for (int i = 0; i < 10; i++)
	{
		if (arr[i] == num)
		{
			found++;
			arr[i]= replace ;
		}
	}
	if (found > 3)
	{
		for (int j = 0; j < 10; j++)
			cout << arr[j] << endl;
	}
	else
	{
		cout << num << " is not present more than 3 times hence cannot be replaced ";
	}
	return 0;
}
