#include<iostream>
using namespace std;
int main()
{
	int arr[6];
	cout << "Enter values :" << endl;
	for (int i =0; i < 6; i++)
		cin >> arr[i];
	int arr1[6];
	int count = 1;
	for (int i =0; i < 5; i++)
	{
;	    arr1[count++] = arr[i];
	}
	arr1[0] = arr[5];
	for (int i = 0; i < 6; i++)
	{
		arr[i] = arr1[i];
	}
	cout << "rotated values" << endl;
	for (int i = 0; i < 6; i++)
	{
		cout << arr[i] << endl;
	}
	return 0;
}