#include<iostream>
using namespace std;
int main()
{
	int arr[10] = { 12,6,7,78,9,10,58,5433,14,5 };
	int num, replace, found = 0,lastfound=-1;
	cout << "Enter number you want to found :";
	cin >> num;
	cout << "Enter your desired Number for replacement :";
	cin >> replace;
	for (int i = 0; i < 10; i++)
	{
		if (arr[i] == num)
		{
			lastfound = i;
			found++;
		}
	}
	arr[lastfound] = replace;
	for (int j = 0; j < 10; j++)
		cout << arr[j] << endl;

	return 0;
}