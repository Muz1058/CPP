#include<iostream>
using namespace std;
int main()
{
	int arr[10] = { 10,20,30,40,50,60,70,80,90,100 };
	int find_num;
	int replacement;
	int count = 0;
	cout << "Enter number to find :";
	cin >> find_num;
	cout << "Enter number by which you want to replace your desire Number :";
	cin >> replacement;
	for (int i = 0; i < 10; i++)
	{
		if (find_num == arr[i])
		{
			arr[i] = replacement;
			count++;
		}
	}
	if (count == 0)
		cout << "Your number is not found and replacement is not able take place";
	else
	{
		cout << "Your given number is present and replaced by your desired number " << endl;
		for (int j = 0; j < 10; j++)
		{
			cout << arr[j] << endl;
		}
	}
	return 0;
}