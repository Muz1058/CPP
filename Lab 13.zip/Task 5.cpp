#include<iostream>
using namespace std;
int main()
{
	int arr[10] = { 5,6,7,5,9,10,58,5,5,66 };
	int num, found = 0,firstfound, lastfound = 0;
	cout << "Enter number you want to found :";
	cin >> num;
	for (int i = 0; i < 10; i++)
	{
		if (arr[i] == num)
		{
			if (found == 0)
			{
				firstfound = i;
				found++;
			}
			else
			{
				lastfound = i;
				found++;
			}
		}
	}
	if (found == 1)
	{
		cout << "Number is present only once ";
	}
	else
	{
		cout << "First occurance is at " << firstfound << " index" << endl;
		cout << "Last occurance is at " << lastfound << " index" << endl;
	}

	return 0;
}