#include<iostream>
using namespace std;
int main()
{
	int arr[10] = { 100,90,80,70,60,50,40,30,20,10 };
	cout << "Array Before Reverse :" << endl;
	for (int i = 0; i < 10; i++)
		cout << arr[i] << endl;

	cout << "Reverse Array :" << endl;

	for (int i = 9; i >= 0; i--)
		cout << arr[i] << endl;

	return 0;
}