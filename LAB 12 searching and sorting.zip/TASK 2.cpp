#include<iostream>
using namespace std;
int main()
{
	int arr[10] = { 10,20,30,40,50,60,70,80,90,100 };
	int user_input;
	int loc=-1;
	cout << "Enter the number you want to found :";
	cin >> user_input;

	for (int index = 0; index < 10; index++)
	{
		if (user_input == arr[index])
			loc = index;
	}
	if (loc != -1)
		cout << "You given number is found at index :" << loc << endl;
	else
		cout << "Number not found";
	return 0;
}