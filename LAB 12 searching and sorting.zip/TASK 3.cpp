#include<iostream>
using namespace std;
int main()
{
	int arr[10] = { 2,3,4,65,5,4,43,656,56,5 };
	int count = 0;
	int user_input;
	cout << "Enter number you want to count :";
	cin >> user_input;
	for (int index = 0; index < 10; index++)
	{
		if (user_input == arr[index])
			count++;
	}
	if (count != 0)
		cout << "Your given number is present " << count << " times";
	else
		cout << "Number not present";
	return 0;
}
