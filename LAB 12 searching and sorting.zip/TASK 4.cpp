#include<iostream>
using namespace std;
int main()
{
	int arr[10] = { -10,-2,-43,-4,-5,-65,-7,-10,0 };
	int min = arr[0], max = arr[0];
	for (int index = 0; index < 10; index++)
	{
		if (arr[index] < min)
			min = arr[index];
		else if (arr[index] > max)
			max = arr[index];
	}
	cout << "Smallest number in the array is :" << min << endl;
	cout << "Largest number in the array is :" << max << endl;
	return 0;
}