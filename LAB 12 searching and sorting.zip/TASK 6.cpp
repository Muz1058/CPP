#include<iostream>
using namespace std;
int main()
{
	int array1[10] = { 10,20,30,40,50,60,70,80,90,100 };
	int array2[10] = { 4,5,673,45,325,57,35,100,34,132 };
	int max = array1[0];
	for (int i = 0; i < 10; i++)
	{
		if (array1[i] > max)
			max = array1[i];
	}
	cout << "maximum number in Array1 is :" << max << endl;
	for (int j = 0; j < 10; j++)
	{
		if (array2[j] == max)
			cout << "Maximum number of Array1 is present in Array2 at index :" << j;
	}
	return 0;
}