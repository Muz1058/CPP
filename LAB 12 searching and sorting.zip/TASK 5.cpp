#include<iostream>
using namespace std;
int main()
{
	int arr[10] = { 2,4,5,66,74,8,54,11,8,45 };
	int count = 0;
	for (int index = 0; index < 10; index++)
	{
		if (index % 2 == 0)
		{
			if (arr[index] % 2 == 0)
			{
				count++;
			}
		}
	}
	cout << "Number of even numbers present at even indexes are :" << count << endl;
	return 0;
}