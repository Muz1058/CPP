#include<iostream>
using namespace std;
int main()
{
	int arr[10] = { 5,2,34,36,321,32,38,334,23,123 };
	int size = 9;
	for (int step = 0; step < size; step++)
	{
		for (int i = 0; i < size - step; i++)
		{
			if (arr[i] > arr[i + 1])
			{
				int temp = arr[i];
				arr[i] = arr[i + 1];
				arr[i + 1] = temp;
			}
		}
	}
	cout << "Second largest number in array is" << arr[size - 1];
	return 0;
}