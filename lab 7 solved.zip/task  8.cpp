#include<iostream>
using namespace std;
int main()
{
	int num, sum = 0,rem;
	cout << "Enter a number:";
	cin >> num;
	int result= num;
	while (num != 0)
	{
		rem = num % 10;
		sum = sum + rem * rem * rem;
		num = num / 10;
	}
	if (result==sum)
	{
		cout << result << ":is an armstrong number";
	}
	else
	{
		cout << result << ":is not an armstrong number";
	}
	return 0;
}