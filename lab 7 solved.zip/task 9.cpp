#include <iostream>
using namespace std;

int main()
{
    int Num1, Num2;
    int sum = 0;
    int sumOfSquares = 0;

    cout << "Enter two integers (Num1 and Num2): ";
    cin >> Num1 >> Num2;

    if (Num1 > Num2)
    {
        int temp = Num1;
        Num1 = Num2;
        Num2 = temp;
    }

    cout << "Numbers between " << Num1 << " and " << Num2 << ":" << endl;

    int currentNum = Num1;
    while (currentNum <= Num2)
    {
        cout << currentNum << " ";
        sum += currentNum;
        sumOfSquares += (currentNum * currentNum);
        currentNum++;
    }

    cout << endl;
    cout << "Sum of numbers between " << Num1 << " and " << Num2 << ": " << sum << endl;

    cout << "Numbers and their squares between " << Num1 << " and " << Num2 << ":" << endl;
    currentNum = Num1;
    while (currentNum <= Num2)
    {
        cout << currentNum << " - " << (currentNum * currentNum) << endl;
        currentNum++;
    }

    cout << "Sum of squares of odd numbers between " << Num1 << " and " << Num2 << ": ";
    currentNum = Num1;
    int oddSumOfSquares = 0;
    while (currentNum <= Num2)
    {
        if (currentNum % 2 != 0)
        {
            oddSumOfSquares += (currentNum * currentNum);
        }
        currentNum++;
    }

    cout << oddSumOfSquares << endl;

    return 0;
}
