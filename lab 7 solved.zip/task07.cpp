#include<iostream>
using namespace std;
int main()
{
	int i = 2, num, prime = 0;
	cout << "Enter a number:";
	cin >> num;
	while (i < num)
	{
		if (num % i == 0)
		{
			prime++;
		}
		i++;
	}
	if (prime == 0)
	{
		cout <<num<< "is number is prime\n";
	}
	else
	{
		cout << "number is not prime\n";
	}


	return 0;
}