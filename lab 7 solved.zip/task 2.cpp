#include<iostream>
using namespace std;
int main()
{
	int num1 = 1, sum = 0;
	cout << "First 10 natural numbers are:\n";
	for (int num1 = 1; num1 <= 10; ++num1)
	{
		cout << num1 << " " ;

		sum += num1;
	}
	cout << "\nSum of the first ten natural numbers is="  << sum << endl;
	 
	return 0;
	


}