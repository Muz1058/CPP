#include<iostream>
using namespace std;
int main()
{
	int num;
	cout << "Enter a Number:";
	cin >> num;
	cout << "table of " << num << "=\n";
	for (int i = 1; i <= 10; ++i)
	{
		cout << num << "*" << i << "=" << num * i << endl;
	}
	return 0;

}