#include <iostream>
using namespace std;

int main() {
    int number;
    int digitSum = 0;

    cout << "Enter a number: ";
    cin >> number;
    cout << "number is: " << number << endl;

    while (number != 0)
    {
        int digit = number % 10;
        digitSum += digit;
        number /= 10;
    }

    cout << "Digit sum for the number is " << digitSum << endl;

    return 0;
}
