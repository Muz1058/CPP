#include<iostream>
using namespace std;
int main()
{
	int num, n;
	int smallest , largest ;
	smallest = largest = n;
	for (int i; i >= 10; i++)
	{
		cout << "Enter number:";
		cin >> num;

		if (num < smallest)
		{
			smallest = num;
		}
		if (num > largest)
		{
			largest = num;
		}
	}
	cout << "smallest" << smallest << endl;
	cout << "largest" << largest << endl;





}
