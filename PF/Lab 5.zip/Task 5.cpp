#include<iostream>
#include<fstream>
using namespace std;
void fun(ifstream& read, char file[],char name[])
{
	char check[50];
	bool found = true;
	read.open(file);
	while (read.getline(check, 50, '\n'))
	{
		int i = 0;
		while (name[i] != '\0')
		{
			if (name[i] != check[i])
			{
				found = false;
			}
			i++;
		}
		if (found)
		{
			cout << "Patient name is present in file ";
			break;
		}
	}
	if (!found)
	{
		cout << "Not found! ";
	}
	read.close();
}
int main()
{
	ifstream read;
	char file[20] = { "patient.txt" };
	char name[25];
	cout << "Enter patient Name :";
	cin.getline(name, 25);
	fun(read, file,name);
	return 0;
}