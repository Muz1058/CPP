#include<iostream>
#include<fstream>
using namespace std;
int main() 
{
	float average;
	ifstream read("average.txt");
	ofstream write("newfile.txt");
	read >> average;
	if (average < 4) {
		write << "Below Average!" << endl;
	}
	else if (4 <= average <= 6) {
		write << "On Average!" << endl;
	}
	else if (average > 6) {
		write << "Above Average!" << endl;
	}
	else {
		write << "Invalid average!" << endl;
	}
	return 0;
}