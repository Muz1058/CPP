#include<iostream>
#include<fstream>
using namespace std;
int count(ifstream& read, char filename[])
{
	char ch;
	int count = 0;
	read.open(filename);
	while (read >> ch)
	{
		if (ch == 'a' || ch == 'A' || ch == 'e' || ch == 'E' || ch == 'i' || ch == 'I' || ch == 'o' || ch == 'O' || ch == 'u' || ch == 'U')
		{
			count++;
		}
	}
	return count;
	read.close();
}
int main()
{
	ifstream read;
	char filename[20] = { "vowel.txt" };

	cout<<"Total vowels in file is :" << count(read, filename);

	return 0;
}