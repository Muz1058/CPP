#include<iostream>
#include<fstream>
using namespace std;
int calculate_square(int length) {
    int square = length * length;
    cout << square;
    return square;
}
void write_square(const char filename[]) {
    ifstream read(filename);
    char arr_name[20];
    int length;
    char coma;
    while (read.getline(arr_name,50,',') >>  length)
    {
        cout << arr_name << " = ";
        calculate_square(length);
        cout << endl;
    }
    read.close();
}
int main() {
    const char filename[20] = "square.txt";
    write_square(filename);
}