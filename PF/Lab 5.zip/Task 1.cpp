#include<iostream>
using namespace std;
void sorting(char arr[], int size)
{
	for (int i = 0; arr[i] != '\0'; i++)
	{
		if (arr[i] >= 'A' || arr[i] <= 'Z')
		{
			for (int j = 0; arr[j] != '\0'; j++)
			{
				if (arr[j] >= 'a' || arr[j] <= 'z')
				{
					int temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
	}
	cout << arr;
}
int main()
{
	const int size = 50;
	char arr[size];
	cout << "enter the string " << endl;
	cin.getline(arr, size);
	sorting(arr, size);
	return 0;
}