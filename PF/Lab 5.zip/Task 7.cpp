#include<iostream>
#include<fstream>
using namespace std;

void display_data(ifstream& read) {
    char read_data[100];
    while (!read.eof()) {
        read.getline(read_data, 100);
        cout << read_data << endl;
    }
    read.close();
}

void add_data(ofstream& write) {
    char name[20];
    int employee_num = 2;
    int age, id, contact_number;
    write << "Employee no." << employee_num << " " << endl;
    cout << "Enter the name of the employee: " << endl;
    cin.getline(name, 20, '\n');
    write << "Name: " << name << endl;
    cout << "Enter the age of the employee: " << endl;
    cin >> age;
    write << "Age: " << age << endl;
    cout << "Enter employee ID: " << endl;
    cin >> id;
    write << "ID: " << id << endl;
    cout << "Enter the contact number of the employee: " << endl;
    cin >> contact_number;
    write << "Contact Number: " << contact_number << endl;
    write << endl;
    employee_num++;
    write.close();
}

int main() {
    const char filename[] = { "employee.txt" };
    int choice;
    do {
        cout << " Press 1 to display employee data \n Press 2 to add new employee data." << endl;
        cin >> choice;
        if (choice == 1) {
            ifstream read(filename);
            display_data(read);
        }
        else if (choice == 2) {
            ofstream write(filename, ios::app);
            add_data(write);
        }
        else {
            cout << "Invalid Input!";
        }
        cout << "\n";
        cout << " Press 3 exit: \n\n Press4 to continue:" << endl;
        cin >> choice;
    } while (choice != 3);

    return 0;
}
