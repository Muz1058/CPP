#include<iostream>
#include<fstream>
using namespace std;
void fun(ifstream& read, char file[], ofstream& even, char file1[], ofstream& odd, char file2[])
{
	int num;
	read.open(file);
	even.open(file1);
	odd.open(file2);
	while (read >> num)
	{
		if (num % 2 == 0)
		{
			even << num << endl;
		}
		else
		{
			odd << num << endl;
		}
	}
	read.close();
	even.close();
	odd.close();
}
int main()
{
	ifstream read;ofstream odd, even;
	char file[20] = { "rollnumber.txt" }, file1[20] = { "evenrollnumbers.txt"}, file2[20] = { "oddrollnumbers.txt"};
	fun(read, file, even, file1, odd, file2);
	return 0;
}