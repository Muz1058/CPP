#include <iostream>

using namespace std;

int main() {
  int arr[10][10], row, col, i, j;

  cout << "Enter the number of rows and columns: ";
  cin >> row >> col;

  cout << "Enter the elements of the matrix: \n";
  for (i = 0; i < row; i++) {
    for (j = 0; j < col; j++) {
      cin >> arr[i][j];
    }
  }

  cout << "\nTranspose Matrix: \n";
  for (i = 0; i < col; i++) {
    for (j = 0; j < row; j++) {
      cout << arr[j][i] << " ";
    }
    cout << endl;
  }

  return 0;
}
