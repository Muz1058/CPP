#include <iostream>

using namespace std;

int main() {
  int arr[10][10], row, col, i;

  cout << "Enter the number of rows and columns: ";
  cin >> row >> col;

  cout << "Enter the elements of the matrix: \n";
  for (i = 0; i < row; i++) {
    for (int j = 0; j < col; j++) {
      cin >> arr[i][j];
    }
  }

  cout << "Diagonal elements: ";
  
  for (i = 0; i < min(row, col); i++) {
    cout << arr[i][i] << " ";
  }

  cout << endl;

  return 0;
}
