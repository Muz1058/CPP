#include <iostream>
using namespace std;

int main() {
  int a[10][10], b[10][10], result[10][10], row, col, i, j;

  cout << "Enter the number of rows and columns: ";
  cin >> row >> col;

  cout << "Enter elements of first matrix: \n";
  for (i = 0; i < row; i++) {
    for (j = 0; j < col; j++) {
      cin >> a[i][j];
    }
  }

  cout << "Enter elements of second matrix: \n";
  for (i = 0; i < row; i++) {
    for (j = 0; j < col; j++) {
      cin >> b[i][j];
    }
  }

  for (i = 0; i < row; i++) {
    for (j = 0; j < col; j++) {
      result[i][j] = a[i][j] + b[i][j];
    }
  }

  cout << "Sum of matrices: \n";
  for (i = 0; i < row; i++) {
    for (j = 0; j < col; j++) {
      cout << result[i][j] << " ";
    }
    cout << endl;
  }

  return 0;
}
