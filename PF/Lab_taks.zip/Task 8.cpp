#include <iostream>

using namespace std;

void calculateSums(int matrix[][10], int N, int rowSums[], int colSums[]) {
  for (int i = 0; i < N; i++) {
    rowSums[i] = 0;
    colSums[i] = 0;
  }

  for (int i = 0; i < N; i++) {
    for (int j = 0; j < N; j++) {
      rowSums[i] += matrix[i][j];
      colSums[j] += matrix[i][j];
    }
  }
}

void printMatrix(int matrix[][10], int N) {
  for (int i = 0; i < N; i++) {
    for (int j = 0; j < N; j++) {
      cout << matrix[i][j] << " ";
    }
    cout << endl;
  }
}

void printSums(int rowSums[], int colSums[], int N) {
  cout << "Row-wise sums: ";
  for (int i = 0; i < N; i++) {
    cout << rowSums[i] << " ";
  }
  cout << endl;

  cout << "Column-wise sums: ";
  for (int i = 0; i < N; i++) {
    cout << colSums[i] << " ";
  }
  cout << endl;
}

int main() {
  int N = 3;
  int matrix[10][10] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
  int rowSums[10], colSums[10];

  cout << "Original Matrix: \n";
  printMatrix(matrix, N);

  calculateSums(matrix, N, rowSums, colSums);

  printSums(rowSums, colSums, N);

  return 0;
}
