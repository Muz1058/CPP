#include <iostream>

using namespace std;

void sortRowWise(int matrix[][4], int rows, int cols) {
  for (int i = 0; i < rows; i++) {
    for (int j = 0; j < cols - 1; j++) {
      for (int k = 0; k < cols - j - 1; k++) {
        if (matrix[i][k] > matrix[i][k + 1]) {
          swap(matrix[i][k], matrix[i][k + 1]);
        }
      }
    }
  }
}

void printMatrix(int matrix[][4], int rows, int cols) {
  cout<<endl;
  for (int i = 0; i < rows; i++) {
    for (int j = 0; j < cols; j++) {
      cout << matrix[i][j] << " ";
    }
    cout << endl;
  }
}

int main() {
  int matrix[4][4] = {{55, 7, 66}, {12, 4, 89, 14}, {56}, {33, 41, 32, 53}};
  int rows = sizeof(matrix) / sizeof(matrix[0]);
  int cols = sizeof(matrix[0]) / sizeof(matrix[0][0]);

  printMatrix(matrix, rows, cols);

  sortRowWise(matrix, rows, cols);

  printMatrix(matrix, rows, cols);

  return 0;
}
