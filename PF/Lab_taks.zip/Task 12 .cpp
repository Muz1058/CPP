#include <iostream>

using namespace std;

int main() {
  int m, n;

  cout << "Enter the dimensions (m x n) of the first vector: ";
  cin >> m >> n;

  int v1[m];
  cout << "Enter the elements of the first vector:\n";
  for (int i = 0; i < m; i++) {
    cin >> v1[i];
  }

  cout << "Enter the dimensions (m x n) of the second vector: ";
  cin >> m >> n;

  int v2[m];
  cout << "Enter the elements of the second vector:\n";
  for (int i = 0; i < m; i++) {
    cin >> v2[i];
  }

  if (m != n) {
    cout << "Error: The vectors must have the same dimensions." << endl;
    return 1;
  }

  int dotProduct = 0;
  for (int i = 0; i < m; i++) {
    dotProduct += v1[i] * v2[i];
  }

  cout << "The dot product of the two vectors is: " << dotProduct<<" "<< endl;

  return 0;
}
