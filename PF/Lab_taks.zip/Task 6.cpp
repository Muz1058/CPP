#include <iostream>

using namespace std;

int main() {
  const int MAX_NAMES = 20;
  char names[MAX_NAMES][MAX_NAMES];
  int num_names = 0;

  
  cout << "Enter names (enter a blank line to stop):" << endl;
  while (true) {
    cin.getline(names[num_names], MAX_NAMES);
    if (names[num_names][0] == '\0') {
      break;
    }
    num_names++;
  }

  
  int row1, row2;
  cout << "Enter two row numbers to swap: ";
  cin >> row1 >> row2;

  for (int i = 0; names[i][0] != '\0'; i++) {
    char temp = names[row1][i];
    names[row1][i] = names[row2][i];
    names[row2][i] = temp;
  }

  cout << "Swapped names:" << endl;
  for (int i = 0; names[i][0] != '\0'; i++) {
    cout << names[i] << endl;
  }

  return 0;
}
