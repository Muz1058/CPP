#include <iostream>

using namespace std;

void transposeMatrix(int matrix[][10], int N) {
  for (int i = 0; i < N; i++) {
    for (int j = i + 1; j < N; j++) {
      int temp = matrix[i][j];
      matrix[i][j] = matrix[j][i];
      matrix[j][i] = temp;
    }
  }
}

void reverseRow(int matrix[][10], int N, int row) {
  for (int i = 0, j = N - 1; i < j; i++, j--) {
    int temp = matrix[row][i];
    matrix[row][i] = matrix[row][j];
    matrix[row][j] = temp;
  }
}

void rotateMatrixClockwise(int matrix[][10], int N) {
  transposeMatrix(matrix, N);
  for (int i = 0; i < N; i++) {
    reverseRow(matrix, N, i);
  }
}

void printMatrix(int matrix[][10], int N) {
  for (int i = 0; i < N; i++) {
    for (int j = 0; j < N; j++) {
      cout << matrix[i][j] << " ";
    }
    cout << endl;
  }
}

int main() {
  int N = 3;
  int matrix[10][10] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};

  cout << "Original Matrix: \n";
  printMatrix(matrix, N);

  rotateMatrixClockwise(matrix, N);

  cout << "\nRotated Matrix: \n";
  printMatrix(matrix, N);

  return 0;
}
