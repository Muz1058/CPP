#include <iostream>

using namespace std;

void sortMatrix(int matrix[][10], int N) {
  for (int i = 0; i < N; i++) {
    for (int j = 0; j < N - 1; j++) {
      
      int min_index = j;
      for (int k = j + 1; k < N; k++) {
        if (matrix[i][k] < matrix[i][min_index]) {
          min_index = k;
        }
      }
      
      if (min_index != j) {
        int temp = matrix[i][j];
        matrix[i][j] = matrix[i][min_index];
        matrix[i][min_index] = temp;
      }
    }
  }
}

void printMatrix(int matrix[][10], int N) {
  for (int i = 0; i < N; i++) {
    for (int j = 0; j < N; j++) {
      cout << matrix[i][j] << " ";
    }
    cout << endl;
  }
}

int main() {
  int N = 4;
  int matrix[10][10] = {{55, 7, 66, 12}, {56, 4, 89, 14}, {33, 41, 32, 53}, {55, 56, 66, 89}};

  cout << "Original Matrix: \n";
  printMatrix(matrix, N);

  sortMatrix(matrix, N);

  cout << "\nSorted Matrix: \n";
  printMatrix(matrix, N);

  return 0;
}
