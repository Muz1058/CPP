#include <iostream>


using namespace std;

void swap(char* a, char* b) {
  char temp = *a;
  *a = *b;
  *b = temp;
}

void bubbleSort(char names[][20], int n) { // Array of char arrays with max size 20
  bool swapped;
  for (int i = 0; i < n - 1; i++) {
    swapped = false;
    for (int j = 0; j < n - i - 1; j++) {
      // Compare names character by character (case-insensitive)
      int k = 0;
      while (names[j][k] != '\0' && names[j + 1][k] != '\0') {
        char char1 = tolower(names[j][k]); // Convert to lowercase for comparison
        char char2 = tolower(names[j + 1][k]);
        if (char1 > char2) {
          swapped = true;
          break;
        } else if (char1 < char2) {
          break;
        }
        k++;
      }
      // If shorter name comes first, swap
      if (names[j][k] == '\0' && names[j + 1][k] != '\0') {
        swapped = true;
      }
      if (swapped) {
        swap(names[j], names[j + 1]);
      }
    }
    // Optimization: Break if no swaps occurred
    if (!swapped) {
      break;
    }
  }
}

int main() {
  char names[][20] = {"Rameel", "Ahmad", "Ali", "Bilal"};
  int n = sizeof(names) / sizeof(names[0]);

  bubbleSort(names, n);

  // Print the sorted names
  cout << "List of Sorted Names\n";
  for (int i = 0; i < n; i++) {
    cout << names[i] << endl;
  }

  return 0;
}
