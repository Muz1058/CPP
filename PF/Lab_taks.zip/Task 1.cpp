#include <iostream>

using namespace std;

int main() {
  int arr[10][10], row, col, i, j;

  cout << "Enter the number of rows and columns: ";
  cin >> row >> col;

  cout << "Enter the elements of the matrix: \n";
  for (i = 0; i < row; i++) {
    for (j = 0; j < col; j++) {
      cin >> arr[i][j];
    }
  }

  cout << "Matrix in reverse order: \n";
  for (i = row - 1; i >= 0; i--) {
    for (j = col - 1; j >= 0; j--) {
      cout << arr[i][j] << " ";
    }
    cout << endl;
  }

  return 0;
}
