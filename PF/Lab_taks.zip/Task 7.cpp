#include <iostream>
#include <cstring>

using namespace std;

int main() {
  char firstName[50], lastName[50], fullName[100]; 

  cout << "Enter first and last names (separated by a space), or type 'q' to quit.\n";

  int ch;
  int i = 0;
  while ((ch = cin.get()) != ' ' && ch != '\n') {
    firstName[i++] = ch;
  }
  firstName[i] = '\0';
  if (ch == 'q') {
    return 0;
  }

  
  while (cin.get() != '\n');

  while (strcmp(firstName, "q") != 0) {
    cout << "Enter last name: ";

    i = 0;
    while ((ch = cin.get()) != '\n') {
      lastName[i++] = ch;
    }
    lastName[i] = '\0'; 
    i = 0;
    while (firstName[i] != '\0') {
      fullName[i] = firstName[i];
      i++;
    }
    fullName[i++] = ' ';
    int j = 0;
    while (lastName[j] != '\0') {
      fullName[i++] = lastName[j++];
    }


    cout << "Full Name: " << fullName << endl;

    cout << "Enter first name (or 'q' to quit): ";

    i = 0;
    while ((ch = cin.get()) != ' ' && ch != '\n') {
      firstName[i++] = ch;
    }
    firstName[i] = '\0'; 


    if (ch == 'q') {
      break;
    }

    
    while (cin.get() != '\n');
  }

  return 0;
}
