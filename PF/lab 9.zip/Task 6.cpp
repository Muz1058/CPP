#include <iostream>
#include <cstring>  
using namespace std;

void inputItemNames(char**& items, int n) {
    for (int i = 0; i < n; ++i) {
        items[i] = new char[50]; 
        cout << "Enter item name " << (i + 1) << ": ";
        cin.getline(items[i], 50);
    }
}

void displayItemNames(char** items, int n) {
    cout << "Item names: ";
    for (int i = 0; i < n; ++i) {
        cout << items[i];
        if (i < n - 1) cout << ", ";
    }
    cout << endl;
}

void sortItemNames(char** items, int n) {
    for (int i = 0; i < n - 1; ++i) {
        for (int j = i + 1; j < n; ++j) {
            if (strcmp(items[i], items[j]) > 0) {
                char temp[50];
                strcpy(temp, items[i]);
                strcpy(items[i], items[j]);
                strcpy(items[j], temp);
            }
        }
    }
}

void findDuplicates(char** items, int n) {
    cout << "Duplicates: ";
    bool found = false;
    for (int i = 0; i < n; ++i) {
        for (int j = i + 1; j < n; ++j) {
            if (strcmp(items[i], items[j]) == 0) {
                if (!found) {
                    cout << items[i];
                    found = true;
                }
                else {
                    cout << ", " << items[i];
                }
                break;
            }
        }
    }
    if (!found) {
        cout << "None";
    }
    cout << endl;
}

void updateItemNames(char**& items, int& n, int newSize) {
    char** newItems = new char* [newSize];
    for (int i = 0; i < newSize && i < n; ++i) {
        newItems[i] = new char[50];
        strcpy(newItems[i], items[i]);
    }
    for (int i = 0; i < n; ++i) {
        delete[] items[i];
    }
    delete[] items;
    items = newItems;
    n = newSize;
}

int main() {
    int n;
    cout << "Number of items (in start): ";
    cin >> n;
    cin.ignore(); 

    char** items = new char* [n];
    inputItemNames(items, n);

    displayItemNames(items, n);

    findDuplicates(items, n);

    sortItemNames(items, n);
    cout << "Sorted items: ";
    displayItemNames(items, n);
    int newSize = 6; 
    updateItemNames(items, n, newSize);

    cout << "Number of items (updated): " << n << endl;

    displayItemNames(items, n);

    findDuplicates(items, n);

    sortItemNames(items, n);
    cout << "Sorted items: ";
    displayItemNames(items, n);

    for (int i = 0; i < n; ++i) {
        delete[] items[i];
    }
    delete[] items;

    return 0;
}
