#include<iostream>
using namespace std;
void arrayShrink(int*& array, int& size, int newSize)
{
	int* new_array = new int[newSize];
	for (int i = 0; i < newSize; i++)
	{
		new_array[i] = array[i];
	}
	delete[] array;
	array = new_array;
}
int main()
{
	int initial_size;
	cout << "Enter Size of Array :: ";
	cin >> initial_size;
	int* initial_array = new int[initial_size];

	for (int i = 0; i < initial_size; i++)
	{
		cout << "Enter " << i + 1 << " Element of array (integer only) :: ";
		cin >> initial_array[i];
	}

	cout << "\nBefore Regrowing \n";
	for (int i = 0; i < initial_size; i++)
	{
		cout << initial_array[i] << "  ";
	}

	int new_size;
	do {
		cout << "\nEnter size of Array to Shrink (Less then initial size) :: ";
		cin >> new_size;
		if (initial_size <= new_size)
		{
			cout << "Invalid input! \nInitial Size of Array is " << initial_size << endl;
		}

	} while (initial_size <= new_size);

	arrayShrink(initial_array, initial_size, new_size);


	cout << "\nArray after Shrink :";
	for (int i = 0; i < new_size; i++)
	{
		cout << initial_array[i] << "  ";
	}
	cout << endl;

	delete[] initial_array;

	return 0;
}