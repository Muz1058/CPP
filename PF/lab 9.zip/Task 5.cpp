#include<iostream>
using namespace std;
double average(int* marks,int size);
int highest_marks(int* marks, int size);
int lowest_marks(int* marks, int size);
void updated_marks(int* marks, int size);
int main()
{
	int initial_students_num,New_students_num;
	cout << "Number of students (in start) :: ";
	cin >> initial_students_num;
	int* marks = new int[initial_students_num];
	for (int i = 0; i < initial_students_num; i++)
	{
		cout << "Enter Marks of Student " << i + 1 << " :: ";
		cin >> marks[i];
	}
	cout << "Students Marks :";
	for (int i = 0; i < initial_students_num; i++)
	{
		cout<< marks[i]<<"  ";
	}
	cout << "\nAverage Marks :" << average(marks, initial_students_num) << endl;
	cout << "Highest Marks :" << highest_marks(marks, initial_students_num) << endl;
	cout << "Lowestest Marks :" << lowest_marks(marks, initial_students_num) << endl;
	updated_marks(marks, initial_students_num);
	cout << "Updated Marks :";
	for (int i = 0; i < initial_students_num; i++)
	{
		cout << marks[i] << "  ";
	}
	cout << "Number of students (updated) :: ";
	cin >> New_students_num;
	int* array = new int[New_students_num];
	cout << "Enter marks for " << New_students_num - initial_students_num << " New students ";

	for (int i = 0; i < New_students_num ; i++)
	{
		if (i < initial_students_num)
		{
			array[i] = marks[i] - 2;
		}
		else
		{
			cin >> array[i];
		}
	}
	cout << "Students Marks :";
	for (int i = 0; i < New_students_num; i++)
	{
		cout << array[i]<<"  ";
	}
	cout << "\nAverage Marks :" << average(array, New_students_num) << endl;
	cout << "Highest Marks :" << highest_marks(array, New_students_num) << endl;
	cout << "Lowestest Marks :" << lowest_marks(array, New_students_num) << endl;
	updated_marks(array, New_students_num);
	cout << "Updated Marks :";
	for (int i = 0; i < New_students_num; i++)
	{
		cout << array[i] << "  ";
	}
	cout << endl;
	delete[] marks;
	delete[] array;
	return 0;
}
double average(int* marks, int size)
{
	double average = 0;
	for (int i = 0; i < size; i++)
	{
		average = average + marks[i];
	}
	return average / size;
}
int highest_marks(int* marks, int size)
{
	int max = marks[0];
	for (int i = 0; i < size; i++)
	{
		if (marks[i] > max)
		{
			max = marks[i];
		}
	}
	return max;
}
int lowest_marks(int* marks, int size)
{
	int min = marks[0];
	for (int i = 0; i < size; i++)
	{
		if (marks[i] < min)
		{
			min = marks[i];
		}
	}
	return min;
}
void updated_marks(int* marks, int size)
{
	for (int i = 0; i < size; i++)
	{
		marks[i] = marks[i] + 2;
	}
}
