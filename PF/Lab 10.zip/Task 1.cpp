//#include<iostream>
//using namespace std;
//int main()
//{
//	int arr[2][3] = { {1,2,3},{4,5,6} };
//	for (int i = 1; i >= 0; i--)
//	{		
//		for (int j = 2; j >= 0; j--)
//		{
//			cout << arr[i][j] << " ";
//		}
//		cout << endl;
//	}
//	return 0;
//}