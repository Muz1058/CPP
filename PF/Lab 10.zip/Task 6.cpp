//#include<iostream>
//using namespace std;
//int main()
//{
//	const int row = 4, col = 3;
//	char arr[4][8] = { {"Ali"},{"Noman"},{"XYZ"},{"Muneeb"} };
//	int input,input1;
//	cout << "enter row 1 :: ";
//	cin >> input  ;
//	//cout << "enter row 2";
//	//cin >> input1;
//	char temp = arr[input - 1][];
//	cout << "Temp =" << temp << endl;
//	for (int i = 0; i < row; i++)
//	{				
//		cout << arr[i]<< " ";			
//		
//	}
//}