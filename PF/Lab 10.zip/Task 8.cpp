//#include<iostream>
//using namespace std;
//int main()
//{
//	const int row = 2, col = 3;
//	int arr[row][col] = { {1,2,3},
//		                  {4,5,6} };
//	int sum;
//	cout << "Row wise sum is :: ";
//	for (int i = 0; i < row; i++)
//	{
//		sum = 0;
//		for (int j = 0; j < col; j++)
//		{
//			sum += arr[i][j];
//		}
//		cout << sum<<"  ";
//	}
//
//	cout << "\nColumn wise sum is :: ";
//	for (int i = 0; i < col; i++)
//	{
//		sum = 0;
//		for (int j = 0; j < row; j++)
//		{
//			sum += arr[j][i];
//		}
//		cout << sum << "  ";
//	}
//	return 0;
//}