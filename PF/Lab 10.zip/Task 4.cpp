//#include<iostream>
//using namespace std;
//int main()
//{
//	const int row = 2, col = 3;
//	int arr[row][col] = { {1,2,3},
//		                  {4,5,6} };
//	for (int i = 0; i < col; i++)
//	{
//		for (int j = 0; j < row; j++)
//		{
//				cout << arr[j][i] << " ";
//		}
//		cout << endl;
//	}
//}