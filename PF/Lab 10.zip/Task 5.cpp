//#include<iostream>
//using namespace std;
//void sortMatrix(int arr[][4],const int row,const int col)
//{
//	for (int i = 0; i < row; i++)
//	{
//		for (int j = 0; j < col; j++)
//		{
//			//Sorting
//			for (int step = 0; step < col - 1; step++)
//			{
//				for (int k = 0; k < col - 1 - step; k++)
//				{
//					if (arr[i][k] > arr[i][k + 1])
//					{
//						int temp = arr[i][k];
//						arr[i][k] = arr[i][k + 1];
//						arr[i][k + 1] = temp;
//					}
//				}
//			}
//		}
//	}
//}
//int main()
//{
//	const int row = 3, col = 4;
//	int arr[row][col] = { {12,55,7,66},{56,4,89,14},{33,41,32,53} };
//	sortMatrix(arr, row, col);	 
//	for (int i = 0; i < row; i++)
//	{
//		for (int j = 0; j < col; j++)
//		{
//
//			cout << arr[i][j] << " ";
//
//		}
//		cout << endl;
//	}
//	return 0;
//}