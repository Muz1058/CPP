//#include<iostream>
//using namespace std;
//int sum(int a, int b)
//{
//	return a + b;
//}
//int main()
//{
//	bool once = true;
//	int A[2][3]= { {1,2,3},{4,5,6} };
//	int B[2][3]= { {9,7,4},{1,2,8} };
//	for (int i = 0; i < 2; i++)
//	{
//		cout << "\t";
//		for (int k = 0; k < 3; k++)
//		{
//			cout << A[i][k]  << " ";
//		}
//		cout<<"\t";
//		for (int k = 0; k < 3; k++)
//		{
//			cout <<  B[i][k] << " ";
//		}
//		cout << "\t";
//		for (int j = 0; j < 3; j++)
//		{
//			cout << sum(A[i][j], B[i][j]) << " ";
//		}
//		if(once)
//			cout << "\n A+B =\t      +\t      =\n";
//		once = false;		
//	}
//	return 0;
//}