//#include<iostream>
//using namespace std;
//int main()
//{
//	const int row = 3,col=4;
//	int arr[row][col] = { {12,55,7,2},{56,4,89,14},{33,41,32,23} };
//	for (int k = 0; k < row; k++)
//	{
//		int temp0 = arr[k][0];
//		for (int i = 0; i < row; i++)
//		{
//			
//			for (int j = 0; j < col; j++)
//			{				
//				if (temp0 > arr[i][j])
//				{
//					int temp = arr[i][j];
//				    arr[i][j]= arr[i][j + 1];
//					//temp0 = arr[i][j + 1];
//					//arr[i][j] = arr[i][j+1];
//					arr[i][j + 1]=temp0;
//					
//				}
//			}
//		}
//	}
//	for (int i = 0; i < row; i++)
//	{
//		for (int j = 0; j < col; j++)
//		{
//			cout << arr[i][j] << " ";
//		}
//		cout << endl;
//	}
//
//
//
//
//
//
//
//
//
//
//	return 0;
//}




#include <iostream>

using namespace std;

void sortMatrix(int matrix[][10], int N) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N - 1; j++) {

            int min_index = j;
            for (int k = j + 1; k < N; k++) {
                if (matrix[i][k] < matrix[i][min_index]) {
                    min_index = k;
                }
            }

            if (min_index != j) {
                int temp = matrix[i][j];
                matrix[i][j] = matrix[i][min_index];
                matrix[i][min_index] = temp;
            }
        }
    }
}

void printMatrix(int matrix[][10], int N) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            cout << matrix[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int N = 4;
    int matrix[10][10] = { {55, 7, 66, 12}, {56, 4, 89, 14}, {33, 41, 32, 53}, {55, 56, 66, 89} };

    cout << "Original Matrix: \n";
    printMatrix(matrix, N);

    sortMatrix(matrix, N);

    cout << "\nSorted Matrix: \n";
    printMatrix(matrix, N);

    return 0;
}
