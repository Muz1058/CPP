//#include<iostream>
//using namespace std;
//int main()
//{
//	const int row = 3, col = 3;
//	int arr[row][col] = { {1,2,3},{4,5,6},{7,8,9} };
//	for (int i = 0; i < row; i++)
//	{
//		for (int j = 0; j < col; j++)
//		{
//			if (i == j)
//			{
//				cout << arr[i][j] << " ";
//			}
//		}
//	}
//}
#include<iostream>
#include<fstream>
using namespace std;

void display(int** arr, int rows, int cols) {
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
}


int main()
{
	int rows, cols, input_choice;

	cout << "\t|--------------------------------------------------------------------------------------|\n";
	cout << "\t|                                                                                      |\n";
	cout << "\t|                                MATRIX MANIPULATOR                                    |\n";
	cout << "\t|                                                                                      |\n";
	cout << "\t|--------------------------------------------------------------------------------------|\n\n";
	cout << "\t<----------INPUT---------->\n";
	cout << "\nFor Matrix entry from file\tPRESS ZERO (0) :: \n";
	cout << "For Matrix entry from file \tPRESS ONE (1) :: \n";
	cout << "Enter 0 or 1 :: ";
	cin >> input_choice;
	if (input_choice == 0)
	{
		cout << "Enter number of rows: ";
		cin >> rows;
		cout << "Enter number of columns: ";
		cin >> cols;

		int** arr = new int* [rows];
		for (int i = 0; i < rows; i++) {
			arr[i] = new int[cols];
		}

		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				cout << "Enter value for arr[" << i << "][" << j << "]: ";
				cin >> arr[i][j];
			}
		}

	

	}
	cout << "Displaying array: " << endl;
	display(arr, rows, cols);

	for (int i = 0; i < rows; i++) {
		delete[] arr[i];
	}

	return 0;
}