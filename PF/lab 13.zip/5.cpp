#include <iostream>
#include <fstream>
using namespace std;


int main()
{
	int rows = 2, col = 10,tempq=0;

	ifstream read("5.txt");
    if (!read.is_open())
    {
        cout << "File not found..";
        return 0;
    }
	

	float** arr_ = new float* [rows];


	for (int i = 0; i < rows; i++)
	{
		arr_[i] = new float[col];
		bool chk=0;

		for (int j = 0; j < col; j++)
		{
			if(chk==0)
			read>>arr_[i][j];
			if(arr_[i][j]==-99)
			chk=1;
			if(chk==1)
			arr_[i][j]=0;
		}
		
		

	}
	read.close();




	for (int i = 0; i < rows; i++)
	{

		for (int j = 0; j < col; j++)
		{
			for (int k = 0; k < col - 1; k++)
			{
				if (arr_[i][k] < arr_[i][k + 1])
				{
					float temp = arr_[i][k];
					arr_[i][k] = arr_[i][k + 1];
					arr_[i][k + 1] = temp;
				}
			}
			


		}
		
	}
cout << "highest marks are ";
	for (int i = 0; i < rows; i++)
	{

		
		cout<<arr_[i][0];
		if(i<rows-1)
		cout<<",";

		
	}
	delete[] arr_;

	return 0;
}