#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    int rows = 2, col = 3,temp=0;

    ifstream read("4.txt");
    if (!read.is_open())
    {
        cout << "File not found..";
        return 0;
    }
   

    int **arr_ = new int *[rows];

    for (int i = 0; i < rows; i++)
    {
        arr_[i] = new int[col];
        for (int j = 0; j < col; j++)
        {
            read >> arr_[i][j];
        }
        read>>temp;
    }
    read.close();

    for (int i = 0; i < col; i++)
    {

        for (int j = 0; j < rows; j++)
        {

            cout << arr_[j][i] << " ";
        }
        cout << endl;
    }
    delete[] arr_;

    return 0;
}