#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    int rows = 4, col = 10, tempq = 0;
    float r_sum = 0, c_sum = 0;

    ifstream read("8.txt");
    if (!read.is_open())
    {
        cout << "File not found..";
        return 0;
    }

    float **arr_ = new float *[rows];

    for (int i = 0; i < rows; i++)
    {
        arr_[i] = new float[col];
        bool chk = 0;

        for (int j = 0; j < col; j++)
        {
            if (chk == 0)
                read >> arr_[i][j];
            if (arr_[i][j] == -99)
                chk = 1;
            if (chk == 1)
                arr_[i][j] = 0;
        }
    }
    read.close();

    

    for (int i = 0; i < rows; i++)
    {

        for (int j = 0; j < col; j++)
        {
            if(arr_[i][j]!=0)
            cout << arr_[i][j] << " ";
        }
        cout<<endl;
    }

    cout<<"sum row wise:";
    for (int i = 0; i < rows; i++)
    {
        r_sum=0;
        for (int j = 0; j < col; j++)
        {
            r_sum+=arr_[i][j];
        }
        cout<<r_sum<<",";
    }
    cout<<endl;
    cout<<"sum column wise:";
    for (int i = 0; i < col; i++)
    {
        c_sum=0;
        for (int j = 0; j < rows; j++)
        {
            c_sum+=arr_[j][i];
        }
        if(c_sum!=0)
        cout<<c_sum<<",";
    }
    cout<<endl;


    delete[] arr_;

    return 0;
}