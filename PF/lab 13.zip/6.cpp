#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    int rows = 4;
    ifstream read("6.txt");
   
    char **arr = new char *[rows + 1];
    for (int i = 0; i < rows; i++)
    {

        arr[i] = new char[100];
        read.getline(arr[i], 100);
    }
    for (int i = 0; i < rows; i++)
    {
        cout << i + 1 << ": " << arr[i] << endl;
    }
    int n1, n2;
    cout << "select any of 2 names to replace:>> ";
    cin >> n1 >> n2;

    arr[rows] = arr[n1-1];
    arr[n1-1] = arr[n2-1];
    arr[n2-1] = arr[rows];
    cout << endl;
    for (int i = 0; i < rows; i++)
    {
        cout << i + 1 << ": " << arr[i] << endl;
    }
    delete[] arr;
}
