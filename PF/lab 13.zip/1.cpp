#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    int rows = 2, col = 3,temp=0;
    ifstream read("1.txt");
    if (!read.is_open())
    {
        cout << "File not found..";
        return 0;
    }
   


    int **arr_ = new int *[rows];

    for (int i = 0; i < rows; i++)
    {
        arr_[i] = new int[col];
        for (int j = 0; j < col; j++)
        {
            read >> arr_[i][j];
        }
        read>>temp;
    }
    read.close();

    for (int i = rows - 1; i >= 0; i--)
    {

        for (int j = col - 1; j >= 0; j--)
        {
            cout << arr_[i][j] << " ";
        }
        cout << endl;
    }

    delete[] arr_;

    return 0;
}