#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    int rows = 2, col = 3,temp=0;
    ifstream read("2.1.txt");
    ifstream read2("2.2.txt");
    if (!read.is_open())
    {
        cout << "File not found..";
        return 0;
    }
   


    int **arr_ = new int *[rows];

    for (int i = 0; i < rows; i++)
    {
        arr_[i] = new int[col];
        for (int j = 0; j < col; j++)
        {
            read >> arr_[i][j];
        }
        read>>temp;
    }

    for (int i = 0; i < rows; i++)
    {
        
        for (int j = 0; j < col; j++)
        {
            read2 >> temp;
            arr_[i][j]+=temp;
        }
        read2>>temp;
    }
    read.close();
    read2.close();

    for (int i = 0; i <rows; i++)
    {

        for (int j =0; j <col; j++)
        {
            cout << arr_[i][j] << " ";
        }
        cout << endl;
    }

    delete[] arr_;

    return 0;
}