#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    int rows = 4;
    ifstream read("7.1.txt");
    ifstream read2("7.2.txt");
    ofstream write;
    write.open("7.3.txt");
   
    char **arr = new char *[rows ];
    for (int i = 0; i < rows; i++)
    {

        arr[i] = new char[100];
        read.getline(arr[i], 100,',');
    }
    read.close();
    char **arr2 = new char *[rows];
    for (int i = 0; i < rows; i++)
    {

        arr2[i] = new char[100];
        read2.getline(arr2[i], 100,',');
    }
    read2.close();    

    for (int i = 0; i < rows; i++)
    {
        cout <<arr[i]<<" "<<arr2[i] << endl;
        write <<arr[i]<<" "<<arr2[i] << endl;
    }
    write.close();
    delete[] arr;
    delete[] arr2;
}
