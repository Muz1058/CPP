#include<iostream>
#include<fstream>
using namespace std;
void display(int**& arr, int& rows, int& cols)
{
	for (int j = 0; j < rows; j++)
	{
		for (int k = 0; k < cols; k++)
		{
			cout << arr[j][k] << " ";
		}
		cout << endl;
	}
}
void sumOfMatrices(int**& sum, int**& arr, int**& arr2, int& rows, int& cols)
{
	sum = new int* [rows];
	for (int i = 0; i < rows; i++)
	{
		sum[i] = new int[cols];
		for (int j = 0; j < cols; j++)
		{
			sum[i][j] = arr[i][j] + arr2[i][j];
		}
	}
	display(sum, rows, cols);
}
void readfile(ifstream& read, int**& arr, int**& arr2, int& rows, int& cols, int& rows2, int& cols2)
{
	read >> rows >> cols;
	arr = new int* [rows];
	for (int j = 0; j < rows; j++)
	{
		arr[j] = new int[cols];
		for (int k = 0; k < cols; k++)
		{
			read >> arr[j][k];
		}
	}
	cout << "First Matrix : " << endl;
	display(arr, rows, cols);
	read >> rows2 >> cols2;
	arr2 = new int* [rows2];
	for (int j = 0; j < rows2; j++)
	{
		arr2[j] = new int[cols2];
		for (int k = 0; k < cols2; k++)
		{
			read >> arr2[j][k];
		}
	}
	cout << "Second Matrix : " << endl;
	display(arr2, rows2, cols2);
	read.close();
}
int main()
{
	int** arr = nullptr;
	int** arr2 = nullptr;
	ifstream read("Task2.txt");
	int row = 0, col = 0, row2 = 0, col2 = 0;
	readfile(read, arr, arr2, row, col, row2, col2);
	if (row == row2 && col == col2)
	{
		cout << "------------->Sum of Matrices<--------------\n";
		int** sum = nullptr;
		sumOfMatrices(sum, arr, arr2, row, col);
		for (int i = 0; i < row; i++)
		{
			delete[] sum[i];
		}
		delete[] sum;
	}
	else
	{
		cout << "\nDimensions of matrix Don't Match!!\n";
	}
	//Deallocation
	for (int i = 0; i < row; i++)
	{
		delete[] arr[i];
	}
	delete[] arr;
	for (int i = 0; i < row2; i++)
	{
		delete[] arr2[i];
	}
	delete[] arr2;
	read.close();
	return 0;
}

