#include<iostream>
#include<fstream>
using namespace std;
void columnWiseDisplay(int**& arr, int row, int col)
{
	cout << "\n------------>Column Wise Display<------------\n";
	for (int i = 0; i < col; i++)
	{
		cout << "| ";
		for (int j = 0; j < row; j++)
		{
			cout << arr[j][i]<<" ";
		}
		cout <<"|"<< endl;
	}
}
void display(int** arr, int row, int col)
{
	cout << "\n-------------->Matrix<--------------\n";
	for (int i = 0; i < row; i++)
	{
		cout << "| ";
		for (int j = 0; j < col; j++)
		{
			cout << arr[i][j] << " ";
		}
		cout << "|" << endl;
	}
}


void readFromFile(int**& arr, int &row, int &col)
{
	ifstream read("Task4.txt");
	read >> row >> col;
	arr = new int* [row];
	for (int i = 0; i < row; i++)
	{
		arr[i] = new int[col];
	}
	while (!read.eof())
	{
		for (int i = 0; i < row; i++)
		{
			for (int j = 0; j< col; j++)
			{
				read >> arr[i][j];
			}
		}
	}
	read.close();
}
int main()
{
	int** arr = nullptr,row=0,col=0;
	readFromFile(arr, row, col);
	display(arr, row, col);
	columnWiseDisplay(arr, row, col);

	for (int i = 0; i < row; i++)
	{
		delete[] arr[i];
	}
	delete[] arr;


	return 0;
}