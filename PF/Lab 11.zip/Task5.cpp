#include<iostream>
#include<fstream>
using namespace std;
void display(int**& arr, int row, int col)
{
	for (int i = 0; i < row; i++)
	{
		cout << "| ";
		for (int j = 0; j < col; j++)
		{
			cout << arr[i][j] << " ";
		}
		cout << "|\n";
	}
}
void rowWiseSorting(int**& arr, int row, int col)
{
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			for (int k = j+1; k < col; k++)
			{
				if (arr[i][j] > arr[i][k])
				{
					int temp = arr[i][j];
					arr[i][j] = arr[i][k];
					arr[i][k] = temp;
				}
			}
		}
	}
}

void readFromFile(ifstream& read,int**& arr, int &row, int &col)
{
	read >> row >> col;
	arr = new int* [row];
	for (int i = 0; i < row; i++)
	{
		arr[i] = new int[col];
	}
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			read >> arr[i][j];
		}
	}
	read.close();
}
int main()
{
	ifstream read("TAsk5.txt");
	int** arr = NULL, row = 0, col = 0;
	readFromFile(read, arr, row, col);
	cout <<"Row ="<<row << "col=" << col << endl;
	cout << "-------------->Matrix<-------------\n";
	display(arr, row, col);
	cout << "\n-------------->Row Wise Sorting<--------------\n";
	rowWiseSorting(arr, row, col);
	display(arr, row, col);
	for (int i = 0; i < row; i++)
	{
		delete[] arr[i];
	}
	delete[] arr;
	read.close();
	return 0;
}