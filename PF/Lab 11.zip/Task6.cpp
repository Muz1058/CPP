#include<iostream>
#include<fstream>
using namespace std;
void display(char**& arr,int row)
{
	for (int i = 0; i < row; i++)
	{
		cout << i+1 <<". " << arr[i] << endl;
	}
}
void swap(char**& arr)
{
	int choice1, choice2;
	cout << "\nSelect 2 names to swap ";
	cout << "Enter First Name (1 to 4) :";
	cin >> choice1;
	cout << "Enter 2nd choice (1 to 4) :";
	cin >> choice2;
	char* temp = arr[choice1 - 1];
	arr[choice1 - 1] = arr[choice2 - 1];
	arr[choice2 - 1] = temp;
	delete temp;
}
void readFromFile(ifstream& read,char**& arr,int &row)
{
	read >> row;
	read.ignore();
	arr = new char * [row];
	int i = 0;
	while (i < row)
	{
		char name[50];
		read.getline(name, 50);
		int j = 0;
		while (name[j] != '\0')
		{
			j++;
		}
		arr[i] = new char[j+1];
		for (int k = 0; k < j+1; k++)
		{
			arr[i][k] = name[k];
		}
		i++;
	}
	read.close();
}
int main()
{
	ifstream read("Task6.txt");
	char** arr;
	int row = 0;
	readFromFile(read, arr, row);
	display(arr, row);
	swap(arr);
	cout << "\n------------>After Swapping<-------------\n";
	display(arr, row);
	for (int i = 0; i < row; i++)
	{
		delete[] arr[i];
	}
	delete[] arr;
	return 0;
}