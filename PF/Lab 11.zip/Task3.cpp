#include<iostream>
#include<fstream>
using namespace std;
void diogonal(int**& arr,int row,int col)
{
	cout << "\n------------>Diagonal<---------------\n";
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j<col; j++)
		{
			
			if (arr[i] == arr[j])
			{
				cout << arr[i][j] << " ";
			}			
		}
	}
}
void display(int**& arr, int row, int col)
{
	cout << "--------------->Matrix<--------------\n";
	for (int i = 0; i < row; i++)
	{
		cout << "|";
		for (int j = 0; j< col; j++)
		{
			cout<< arr[i][j]<<" ";
		}
		cout << "|";
		cout << endl;
	}
}
void readFromFile(int**& arr, int &row, int &col)
{
	ifstream read("Task3.txt");
	read >> row >> col;
	arr = new int* [row];
	for (int i = 0; i < row; i++)
	{
		arr[i] = new int[col];
	}
	while (!read.eof())
	{
		for (int i = 0; i < row; i++)
		{
			for (int j = 0; j< col; j++)
			{
				read >> arr[i][j];
			}
		}
	}
	read.close();
}
int main()
{
	int** arr = NULL;
	int row = 0;
	int col = 0;
	readFromFile(arr,row,col);
	display(arr, row, col);
	diogonal(arr, row, col);
	return 0;
}