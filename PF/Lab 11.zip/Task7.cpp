#include <iostream>
#include <fstream>
using namespace std;
int main() {
    ifstream file1("Task7.1.txt");
    ifstream file2("Task7.2.txt");
    ofstream write("Task7.txt");

    int row1 = 0, row2 = 0;
    char** arr = NULL;
    char** arr1 = NULL;

    file1 >> row1;
    file1.ignore(); 

    arr = new char* [row1];
    char temp[100] = "\0"; 
    int count1 = 0;

    int* length = new int[row1];

    // Read lines from file1
    while (count1 < row1) 
    { 
        file1.getline(temp, 100);
        int len = 0;
        while (temp[len] != '\0') {
            len++;
        }
        length[count1] = len;

        arr[count1] = new char[len + 1];

        for (int i = 0; i < len + 1; i++)
        { 
            arr[count1][i] = temp[i];
        }
        //cout << arr[count1] << endl;
        count1++;
    }

  
    file2 >> row2;
    file2.ignore();

    arr1 = new char* [row2];
    char temp1[100] = "\0";
    int count2 = 0;

    int* length1 = new int[row2];

    
    while (count2 < row2) 
    {
        file2.getline(temp1, 100);
        int len1 = 0;
        while (temp1[len1] != '\0') {
            len1++;
        }
        length1[count2] = len1;
        arr1[count2] = new char[len1 + 1];
        for (int i = 0; i < len1 + 1; i++) 
        {
            arr1[count2][i] = temp1[i];
        }
       // cout << arr1[count2] << endl;
        count2++;
    }
    cout << endl;

    char** array = NULL;

    int resultRow = (row1 < row2) ? row1 : row2; 

    array = new char* [resultRow];


    for (int i = 0; i < resultRow; i++)
    {
        int totalLength = length[i] + length1[i];
        array[i] = new char[totalLength + 1];
        for (int j = 0; j < length[i]; j++)
        {
            array[i][j] = arr[i][j];
        }
        for (int j = 0; j < length1[i]; j++)
        {
            array[i][length[i] + j] = arr1[i][j];
        }
        array[i][totalLength] = '\0'; 
    }


    for (int i = 0; i < resultRow; i++)
    {
        write << array[i] << endl;
        delete[] array[i];
    }


    delete[] array;
    for (int i = 0; i < row1; i++)
    {
        delete[] arr[i];
    }
    delete[] arr;
    for (int i = 0; i < row2; i++) 
    {
        delete[] arr1[i];
    }
    delete[] arr1;
    delete[] length;
    delete[] length1;

    file1.close();
    file2.close();
    write.close();

    return 0;
}

//#include <iostream>
//#include <fstream>
//
//using namespace std;
//
//// Function to swap two strings
//void swap(char** a, char** b) {
//    char* temp = *a;
//    *a = *b;
//    *b = temp;
//}
//
//// Function to sort an array of strings using bubble sort
//void bubbleSort(char** arr, int n) {
//    for (int i = 0; i < n - 1; i++) {
//        for (int j = 0; j < n - i - 1; j++) {
//            if (strcmp(arr[j], arr[j + 1]) > 0) {
//                swap(&arr[j], &arr[j + 1]);
//            }
//        }
//    }
//}
//
//int main() {
//    ifstream infile("Task7.1.txt");
//    if (!infile.is_open()) {
//        cout << "Error opening file." << endl;
//        return 1;
//    }
//
//    int n;
//    infile >> n;
//    infile.ignore(); // Ignore newline after reading the integer
//
//    // Dynamically allocate an array of char pointers
//    char** names = new char* [n];
//
//    // Read the names from the file
//    for (int i = 0; i < n; i++) {
//        char buffer[100];
//        infile.getline(buffer, 100);
//
//        // Allocate memory for each name
//        int length = 0;
//        while (buffer[length] != '\0') {
//            length++;
//        }
//        names[i] = new char[length + 1];
//
//        // Copy the name to the allocated memory
//        for (int j = 0; j <= length; j++) {
//            names[i][j] = buffer[j];
//        }
//    }
//
//    infile.close();
//
//    // Print the list of names
//    cout << "List of names:" << endl;
//    for (int i = 0; i < n; i++) {
//        cout << names[i] << endl;
//    }
//
//    // Sort the names using bubble sort
//    bubbleSort(names, n);
//
//    // Print the sorted list of names
//    cout << "\nList of Sorted Names:" << endl;
//    for (int i = 0; i < n; i++) {
//        cout << names[i] << endl;
//    }
//
//    // Deallocate the memory
//    for (int i = 0; i < n; i++) {
//        delete[] names[i];
//    }
//    delete[] names;
//
//    return 0;
//}
//
