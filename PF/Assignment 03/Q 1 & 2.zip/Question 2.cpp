#include <iostream>
#include <fstream>
using namespace std;

#define MAX_SIZE 100

bool isNumeric(char ch) {
    return ch >= '0' && ch <= '9';
}

int performCalculation(int operand1, int operand2, char operatorSymbol) {
    switch (operatorSymbol) {
    case '+':
        return operand1 + operand2;
    case '-':
        return operand1 - operand2;
    case '*':
        return operand1 * operand2;
    case '/':
        return operand1 / operand2;
    default:
        return 0;
    }
}

int getStringLength(char* str) {
    int length = 0;
    while (str[length] != '\0') {
        length++;
    }
    return length;
}

int evaluateExpression(char* expression, int length) {
    int numbers[MAX_SIZE];
    char operators[MAX_SIZE];
    int numTop = -1, opTop = -1;

    for (int i = 0; i < length; i++) {
        if (expression[i] == ' ') {
            continue;
        }

        if (isNumeric(expression[i])) {
            int num = 0;
            while (i < length && isNumeric(expression[i])) {
                num = num * 10 + (expression[i] - '0');
                i++;
            }
            numbers[++numTop] = num;
            i--;
        }
        else if (expression[i] == '(') {
            operators[++opTop] = expression[i];
        }
        else if (expression[i] == ')') {
            while (opTop >= 0 && operators[opTop] != '(') {
                int operand2 = numbers[numTop--];
                int operand1 = numbers[numTop--];
                char op = operators[opTop--];
                numbers[++numTop] = performCalculation(operand1, operand2, op);
            }
            opTop--;
        }
        else {
            while (opTop >= 0 && operators[opTop] != '(' && (
                (expression[i] == '+' || expression[i] == '-') ||
                (expression[i] == '*' || expression[i] == '/') && (operators[opTop] == '+' || operators[opTop] == '-'))) {
                int operand2 = numbers[numTop--];
                int operand1 = numbers[numTop--];
                char op = operators[opTop--];
                numbers[++numTop] = performCalculation(operand1, operand2, op);
            }
            operators[++opTop] = expression[i];
        }
    }

    while (opTop >= 0) {
        int operand2 = numbers[numTop--];
        int operand1 = numbers[numTop--];
        char op = operators[opTop--];
        numbers[++numTop] = performCalculation(operand1, operand2, op);
    }

    return numbers[numTop];
}

int main() {
    ifstream inputFile("Expression.txt");
    if (!inputFile) {
        cout << "Error: Could not open file." << endl;
    }

    char line[MAX_SIZE];
    while (inputFile.getline(line, MAX_SIZE)) {
        int length = getStringLength(line);
        if (length > 0) {
            int result = evaluateExpression(line, length);
            cout << line << " = " << result << endl;
        }
    }

    inputFile.close();
    return 0;
}