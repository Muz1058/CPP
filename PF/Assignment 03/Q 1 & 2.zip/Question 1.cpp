#include<iostream>
using namespace std;
void TextCompare(int* X, int* Y);
int main()
{
	cout << "\n<------------Enter two strings of same Length------------>\n\n";
	char x[50];
	cout << "Enter First string-------> ";
	cin.getline(x, 50);
	char* X = x;
	char y[50];
	cout << "Enter Second string------> ";
	cin.getline(y, 50);
	char* Y = y;


	int len_x = 0, len_y = 0;
	while (X[len_x] != '\0')
	{
		len_x++;
	}
	while (Y[len_y] != '\0')
	{
		len_y++;
	}
	//For typcasting of NUll character +1 add
	len_x = len_x + 1;
	len_y = len_y + 1;

	if (len_x == len_y)
	{

		int* INTx = new int[len_x];
		int* INTy = new int[len_y];


		for (int i = 0; i < len_x; i++)
		{
			INTx[i] = int(x[i]);
		}
		for (int i = 0; i < len_y; i++)
		{
			INTy[i] = int(y[i]);
		}

		TextCompare(INTx, INTy);
		delete[] INTx;
		delete[] INTy;
	}
	else
	{
		cout << "\n\tLength of both strings is not equal!        \n\tTry Again Later!";
	}

	return 0;
}

void TextCompare(int* X, int* Y)
{
	int len = 0, k = 0;;
	while (X[len] != 0)
	{
		len++;

	}
	cout << "\nResultant String is------> ";

	while (k < len - 1)
	{
		if (X[k] != Y[k])
		{
			cout << "-" << char(X[k]) << " ";
		}
		else
		{
			cout << char(X[k]) << " ";
		}

		k++;
	}
	int l = 0;
	while (l < len - 1)
	{
		if (X[l] != Y[l])
		{
			cout << "+" << char(Y[l]) << " ";
		}
		l++;
	}
	if (X[len - 1] == Y[len - 1])
	{
		cout << char(X[len - 1]) << endl;
	}
	else
	{
		cout << "+" << char(Y[len - 1]) << " -" << char(X[len - 1])<<endl;
	}
}