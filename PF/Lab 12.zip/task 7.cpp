#include <iostream>
#include <fstream>
using namespace std;
void rowcount(ifstream& read, int& row)
{
    char line[100];
    int col = 1;
    while (read.getline(line, 100))
    {
        row++;
    }
}
void display(char**& arr, int row)
{
    for (int i = 0; i < row; i++)
    {
        cout << i + 1 << ". " << arr[i] << endl;
    }
}
int main() {
    ifstream fileA("Data.txt");
    ifstream fileB("Data1.txt");
    ofstream write("Task7.txt");
  
    int row1 = 0, row2 = 0;
    rowcount(fileA, row1);
    rowcount(fileB, row2);

    fileA.close();
    fileB.close();

    ifstream file1("Data.txt");
    ifstream file2("Data1.txt");
    char** arr = NULL;
    char** arr1 = NULL;


    arr = new char* [row1];
    char temp[100] = "\0";
    int count1 = 0;
    int* length = new int[row1];
    while (count1 < row1)
    {
        file1.getline(temp, 100);
        int len = 0;
        while (temp[len] != '\0') {
            len++;
        }
        length[count1] = len;

        arr[count1] = new char[len + 1];

        for (int i = 0; i < len + 1; i++)
        {
            arr[count1][i] = temp[i];
        }
        //cout << arr[count1] << endl;
        count1++;
    }

    arr1 = new char* [row2];
    char temp1[100] = "\0";
    int count2 = 0;

    int* length1 = new int[row2];


    while (count2 < row2)
    {
        file2.getline(temp1, 100);
        int len1 = 0;
        while (temp1[len1] != '\0') {
            len1++;
        }
        length1[count2] = len1;
        arr1[count2] = new char[len1 + 1];
        for (int i = 0; i < len1 + 1; i++)
        {
            arr1[count2][i] = temp1[i];
        }
        // cout << arr1[count2] << endl;
        count2++;
    }
    char** array = NULL;

    int resultRow = (row1 < row2) ? row1 : row2;

    array = new char* [resultRow];


    for (int i = 0; i < resultRow; i++)
    {
        int totalLength = length[i] + length1[i];
        array[i] = new char[totalLength + 1];
        for (int j = 0; j < length[i]; j++)
        {
            array[i][j] = arr[i][j];
        }
        for (int j = 0; j < length1[i]; j++)
        {
            array[i][length[i] + j] = arr1[i][j];
        }
        array[i][totalLength] = '\0';
    }


    for (int i = 0; i < resultRow; i++)
    {
        write << array[i] << endl;
        cout << array[i] << endl;
        delete[] array[i];
    }


    delete[] array;
    for (int i = 0; i < row1; i++)
    {
        delete[] arr[i];
    }
    delete[] arr;
    for (int i = 0; i < row2; i++)
    {
        delete[] arr1[i];
    }
    delete[] arr1;
    delete[] length;
    delete[] length1;

    file1.close();
    file2.close();
    write.close();

    return 0;
}