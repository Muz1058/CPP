#include<iostream>
#include<fstream>
using namespace std;
void rowCol(ifstream& read, int& row, int& col)
{
	char temp[100];
	while (read.getline(temp, 200))
	{
		int len = 0, i = 0;
		while (temp[i] != '\0')
		{
			if (temp[i] == ' ')
			{
				len++;
			}
			i++;
		}
		col = len;
		row++;
	}
}
void readFromFile(ifstream& read, int**& arr, int row, int col)
{
	arr = new int* [row];
	for (int i = 0; i < row; i++)
	{
		arr[i] = new int[col];
	}
	int temp = 0;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col + 1; j++)
		{
			read >> temp;
			if (temp != -99)
			{
				arr[i][j] = temp;
			}
		}
	}

}

void displayDiagonal(int**& arr, int& row, int& col)
{
	for (int i =0;i<row;i++)
	{
		for (int j =0;j<col;j++)
		{
			if (i == j)
			{
				cout << arr[i][j] << " ";
			}
		}
	}
}
int main()
{
	ifstream read("task1.txt");
	int row = 0, col = 0;
	int** arr = NULL;

	rowCol(read, row, col);
	read.close();
	ifstream read1("task1.txt");
	readFromFile(read1, arr, row, col);
	cout << "Diagonal =";
	displayDiagonal(arr, row, col);

	for (int i = 0; i < row; i++)
	{
		delete[] arr[i];
	}
	delete[] arr;

	return 0;
}