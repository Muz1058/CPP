#include<iostream>
#include<fstream>
using namespace std;
void rowCol(ifstream& read, int& row, int& col)
{
	char temp[100];
	while (read.getline(temp, 200))
	{
		int len = 0, i = 0;
		while (temp[i] != '\0')
		{
			if (temp[i] == ' ')
			{
				len++;
			}
			i++;
		}
		col = len;
		row++;
	}
}
void readFromFile(ifstream& read, int**& arr, int row, int col)
{
	arr = new int* [row];
	for (int i = 0; i < row; i++)
	{
		arr[i] = new int[col];
	}
	int temp = 0;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col + 1; j++)
		{
			read >> temp;
			if (temp != -99)
			{
				arr[i][j] = temp;
			}
		}
	}

}

void display(int**& arr, int& row, int& col)
{
	for (int i =0;i<row;i++)
	{
		for (int j =0;j<col;j++)
		{
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
}
int main()
{
	ifstream read("task1.txt");
	ifstream read2("task2.txt");
	int row = 0, col = 0,row1=0,col1=0;
	int** arr = NULL;
	int** arr1 = NULL;
	rowCol(read, row, col);
	rowCol(read2, row1, col1);
	read.close();
	read2.close();
	ifstream read1("task1.txt");
	ifstream read3("task2.txt");
	readFromFile(read1, arr, row, col);
	readFromFile(read3, arr1, row1, col1);

	if (row == row1 && col == col1)
	{
		cout << "---------------sum--------------\n";
		int** sum = new int* [row];
		for (int i = 0; i < row; i++)
		{
			sum[i] = new int[col];
		}

		for (int i = 0; i < row; i++)
		{
			for (int j = 0; j < col; j++)
			{
				sum[i][j] = arr[i][j] + arr1[i][j];
			}
		}
		display(sum, row, col);
		for (int i = 0; i < row; i++)
		{
			delete[] sum[i];
		}
		delete[] sum;
	}
	else
	{
		cout << "Dimmensions of matrix dont match " << endl;
	}


	for (int i = 0; i < row; i++)
	{
		delete[] arr[i];
	}
	delete[] arr;
	for (int i = 0; i < row1; i++)
	{
		delete[] arr1[i];
	}
	delete[] arr1;
	return 0;
}