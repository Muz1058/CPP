#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    int rows =20;
    ifstream read("11.txt");
    
   
    char **arr = new char *[rows ];
    for (int i = 0; !read.eof(); i++)
    {

        arr[i] = new char[100];
        read.getline(arr[i], 100,'B');
        if(i!=0)
        cout<<"B";
          cout <<arr[i]<<endl;
    }
    read.close();
       

    
   
    delete[] arr;
    
}
