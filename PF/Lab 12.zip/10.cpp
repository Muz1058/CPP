#include <iostream>
#include <fstream>
using namespace std;

int main()
{
	int rows = 3,tempr;
	int a[3]={3,5,3};

	ifstream read("9.txt");
	

	int **arr_ = new int *[rows];

	for (int i = 0; i < rows; i++)
    {
        arr_[i] = new int[a[i]];
        

        for (int j = 0; j < a[i]; j++)
        {
            read>>arr_[i][j];
        }
		read>>tempr;
    }
    read.close();

	cout << "original matrix\n";
	for (int i = 0; i < rows; i++)
	{

		for (int j = 0; j < a[i]; j++)
		{

			cout << arr_[i][j] << " ";
		}
		cout << endl;
	}
    int aa=0,b=0;
    cout<<"Enter (row,col) to delete:";
    cin>>aa>>b;

	arr_[aa-1][b-1]=0;

	cout << "\n\nupdated matrix\n";
	for (int i = 0; i < rows; i++)
	{

		for (int j = 0; j < a[i]; j++)
		{

            if(arr_[i][j]!=0)
			cout << arr_[i][j] << " ";
		}
		cout << endl;
	}

	delete[] arr_;

	return 0;
}