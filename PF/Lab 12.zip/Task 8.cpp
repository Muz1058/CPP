#include<iostream>
#include<fstream>
using namespace std;

void rowCol(ifstream& read, int& rows, int*& cols)
{
	char line[100];
	int col = 1;
	while (read.getline(line, 100))
	{
		int len = 1;
		int i = 0;
		while (line[i] != '\0')
		{
			if (line[i] == ' ')
			{
				len++;
			}
			i++;
		}
		cols[rows] = len;
		rows++;
	}
}
void readFromFile(ifstream& read, float**& arr, int rows, int*& cols)
{
	arr = new float* [rows];
	for (int i = 0; i < rows; i++)
	{
		arr[i] = new float[cols[i]];
	}
	read.ignore();
	read.seekg(0);
	float temp = 0.00;

	while (!read.eof())
	{
		for (int i = 0; i < rows; i++)
		{
			for (int j = 0; j < cols[i]; j++)
			{
				read >> arr[i][j];
				if (arr[i][j] == -99)
				{
					arr[i][j] = 0.0;
				}
			}
		}
	}
	read.close();
}
void displaySumRow(float** arr, int rows, int*& cols)
{
	cout << "Row wise sum :";
	for (int i = 0; i < rows; i++)
	{		
		float sum = 0.0;
		for (int j = 0; j < cols[i] - 1; j++)
		{
		  sum+= arr[i][j];
			
		}
		cout << sum << ",";
	}
}
void displaySumCol(float** arr, int rows, int*& cols)
{
	cout << "\nColumn wise sum :";
	int maxCols = 0;
	for (int i = 0; i < rows; i++)
	{
		if (cols[i] > maxCols) 
		{
			maxCols = cols[i];
		}
	}

	for (int j = 0; j < maxCols-1; j++)
	{
		float sum = 0.0; 
		for (int i = 0; i < rows; i++)
		{
			if (j < cols[i])
			{ 
				sum += arr[i][j];
			}
		}
		cout << sum << ",";
	}
}

int main()
{
	ifstream read("Data.txt");
	int rows = 0;
	int* cols = new int[100];
	float** arr = NULL;
	rowCol(read, rows, cols);
	read.close();
	ifstream read1("Data.txt");
	readFromFile(read1, arr, rows, cols);
	displaySumRow(arr, rows, cols);
	displaySumCol(arr, rows, cols);

	for (int i = 0; i < rows; i++)
	{
		delete[] arr[i];
	}
	delete[] arr;
	delete[] cols;

	read.close();
	return 0;
}