#include <iostream>
#include <fstream>
using namespace std;
int main() {
    ifstream file1("File1.txt");
    ifstream file2("File2.txt");
    ofstream file3("Output.txt");
    int* nums1 = nullptr;
    int* nums2 = nullptr;
    int count1 = 0,count2=0;
    int num;
    while (file1 >> num) {
        int* temp = new int[count1 + 1];
        for (int i = 0; i < count1; i++) {
            temp[i] = nums1[i];
        }
        delete[] nums1;
        temp[count1] = num;
        nums1 = temp;
        count1++;
    }
    while (file2 >> num) {
        int* temp = new int[count2 + 1];
        for (int i = 0; i < count2; i++) {
            temp[i] = nums2[i];
        }
        delete[] nums2;
        temp[count2] = num;
        nums2 = temp;
        count2++;
    }
    int size;
    if (count1 > count2) {
        size = count1;
    }
    else {
        size = count2;
    }

    int* sums = new int[size];
    for (int i = 0; i < size; i++) {
        sums[i] = 0;
    }

    for (int i = 0; i < count1; i++) {
        sums[i] += nums1[i]+nums2[i];
        file3 << sums[i] << " ";
        cout << sums[i] << " ";
    }

    delete[] nums1;
    delete[] nums2;
    delete[] sums;
    file1.close();
    file2.close();
    file3.close();

    return 0;
}