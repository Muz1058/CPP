#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	ifstream read("Input_task1.txt");
	ofstream write("output_task1.txt");
	int salary, sum = 0;
	char name[20];
	int* pointer = &salary;
	int* point_sum = &sum;
	while (read.getline(name, 20, ' '))
	{
		read >> *pointer;
		*point_sum += *pointer;
	}
	write << "The total salary = " << *point_sum;
	cout << "The total salary = " << *point_sum;
	read.close();
	write.close();
	return 0;
}