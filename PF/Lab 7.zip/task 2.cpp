#include<iostream>
#include<fstream>
using namespace std;
int factorial(int* num)
{
	cout << "Num =" << *num << endl;
	int fact = 1;
	for (int i = *num; i > 0; i--)
	{
		fact *= i;
	}
	return fact;
}
int cube(int* num)
{
	return (*num) * (*num) * (*num);
}
int square(int* num)
{
	return (*num) * (*num);
}
int main()
{

	char repeat;
	do {
		int* x = new int;
		cout << "Enter the number :";
		cin >> *x;
		int get;
		cout << endl << "Press 1 for factorial " << endl;
		cout << "Press 2 for Cube " << endl;
		cout << "Press 3 for square " << endl;
		cout << "Enter your choice 1/2/3 :";
		cin >> get;
		if (get == 1)
		{
			cout << "\nFactorial of " << *x << " is =" << factorial(x) << endl;
		}
		else if (get == 2)
		{
			cout << "\ncube of " << *x << " is =" << cube(x) << endl;
		}
		else if (get == 3)
		{
			cout << "\nSqure of " << *x << " is =" << square(x) << endl;
		}
		else
		{
			cout << "/nInvali Input!" << endl;
		}
		delete x;
		cout << "\nEnter Y to continue" << endl;
		cout << "Enter N to Exit " << endl;
		cout << "Enter choice Y/N :";
		cin >> repeat;
	} while (repeat == 'y' || repeat == 'Y');


	return 0;
}