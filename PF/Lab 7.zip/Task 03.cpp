#include<iostream>
#include<fstream>
using namespace std;
char Lower_case(char c)
{
    if (c >= 'A' && c <= 'Z')
    {
        return c + 32;
    }
    return c;
}
int main()
{
	ifstream read("input_task3.txt");
    ofstream write("output_task3.txt");
	int size = 0;
	while (read >> size)
	{
		size = size + 1;
		char* pointer = new char[size];
		read.getline(pointer, size);
        for (int i = 0; i < size; i++)
        {
            int count = 0;
            for (int j = 0; j < size; j++)
            {
                if (Lower_case(pointer[i]) == Lower_case(pointer[j]))
                {
                    count++;
                }
            }
            if (count == 1)
            {
                cout << pointer[i];
                write << pointer[i];
            }            
        }
        delete[] pointer;
        write << endl;
        cout << endl;
	}
	read.close();

    return 0;
}