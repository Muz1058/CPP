#include<iostream>
using namespace std;
int main()
{
	int num1;
	cout << "Enter price of wheat \n";
	cin >> num1;
	int num2;
	cout << "Enter value of rice \n";
	cin >> num2;
	int num3;
	cout << "Enter value of sugar \n";
	cin >> num3;
	cout << "---------------------------- \n";
	cout << "value of wheat \t \t"<<num1<<endl;
	cout << "value of rice \t \t" << num2 << endl;
	cout << "value of sugar \t \t" << num3 << endl;
	cout << "----------------------------";




	return 0;
}