#include<iostream>
using namespace std;
int main()
{
	int num1;
	cout << "Enter value of fuel \n";
	cin >> num1;
	int num2;
	cout << "Enter value of rent \n";
	cin >> num2;
	int num3;
	cout << "Enter value of bills \n";
	cin >> num3;
	cout << "------------------ \n";
	cout << "fuel  \t \t" << num1 << endl;
	cout << "rent  \t \t" << num2 << endl;
	cout << "bills  \t \t" << num3 << endl;
	cout << "------------------";




	return 0;
}