#include<iostream>
using namespace std;
int main()
{
	int num1;
	cout << "Enter value of Chemistry \n";
	cin >> num1;
	int num2;
	cout << "Enter value of Maths \n";
	cin >> num2;
	int num3;
	cout << "Enter value of Physics \n";
	cin >> num3;
	cout << "--------------------------------- \n";
	cout << "math  \t chemistry \t physics \t" << endl;
	cout << num1 << " \t  \t \t" << num2 << " \t  \t \t" << num3 << "\t \t" << endl;
	cout << "---------------------------------";




	return 0;
}