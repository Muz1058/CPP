#include<iostream>
using namespace std;
int main()
{
	int hours, minutes;

	cout << "Enter hours: ";
	cin >> hours;

	cout << "Enter minutes: ";
	cin >> minutes;

	int sum = hours * 60 + minutes;

	cout << "Total time in minutes: " << sum << endl;


	return 0;
}