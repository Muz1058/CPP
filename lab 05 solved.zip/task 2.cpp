#include <iostream>
using namespace std;
int main()
{
	int num1;
	cout << "Enter Variable Value of first variable: \t";
	cin >> num1;
	int num2;
	cout << "Enter Variable Value of second variable: \t";
	cin >> num2;
	int sum;
	sum = num1 + num2;
	cout << "sum of values : \n"<<sum<<endl;
	int subtract;
	subtract = num1 - num2;
	cout << "Difference of values : \n" << subtract << endl;
	int product;
	product = num1 * num2;
	cout << "product of values : \n" << product << endl;
	int div;
	div = num1 / num2;
	cout << "division of values : \n" << div << endl;

	return 0;
}
