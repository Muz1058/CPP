#include<iostream>
using namespace std;

int main() {

    int INCHES_PER_FOOT = 12;
    int heightFeet, heightInches;
    cout << "Enter height in feet: ";
    cin >> heightFeet;
    heightInches = heightFeet * INCHES_PER_FOOT;
    cout << "height in inches : " << heightInches << " inches" << endl;

    return 0;
}
