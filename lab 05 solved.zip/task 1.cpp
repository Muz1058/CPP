#include <iostream>
using namespace std;
int main()
{
	int num1;
   cout << "Enter Variable Value : \t";
   cin >> num1;
   cout << "Variable Value Entered : \t " << num1;


   return 0;
}

