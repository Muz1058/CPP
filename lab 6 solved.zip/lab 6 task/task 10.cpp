#include<iostream>
using namespace std;
int main()
{
	int unitcharges;
	float bill, totalbill;
	cout << "Enter the value of Electricity unit charges:";
	cin >> unitcharges;

	if (unitcharges <= 50)
	{
		bill = unitcharges * 0.50;
	}

	else if (unitcharges <= 150)
	{
		bill = unitcharges * 0.75;
	}

	else if (unitcharges <= 250)
	{
		bill = unitcharges * 1.20;
	}

	else
	{
		bill = unitcharges * 1.50;
	}

	totalbill = bill * 0.20;

	cout << "Total Electricity Bill is RS:" << totalbill;

}
