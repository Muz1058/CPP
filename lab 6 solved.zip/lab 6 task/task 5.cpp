#include <iostream>
using namespace std;
int main()
{
	float loan, balance, interestmultiplier, interestrate;

	cout << "Enter the value of loan (1000pkr-10000pkr):";
		cin >> loan;

		cout << "Enter the value of balance (10000pkr-50000pkr):";
		cin >> balance;

		if (balance >= 45000)
		{
			interestmultiplier = 0.5;
		}

		if (balance >= 35000)
		{
			interestmultiplier = 0.7;
		}

		if (balance >=25000)
		{
			interestmultiplier = 0.9;
		}

		if (balance >=10000)
		{
			interestmultiplier = 1.2;
		}

		interestrate = loan * interestmultiplier;
		
		cout << "interest rate=" << interestrate;
		
		return 0;

}