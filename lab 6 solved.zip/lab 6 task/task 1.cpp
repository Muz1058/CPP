#include <iostream>
using namespace std;
int main()
{
	float age;
	cout << "enter the age of person in years:";
	cin >> age;
	if (age > 18)
	{
		cout << "eligible to vote";
	}
	return 0;
}