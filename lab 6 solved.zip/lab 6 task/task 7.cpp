#include <iostream>
using namespace std;
int main()
{
	int year;
	cout << "Enter the year:";
		cin >> year;
		if (year % 4 == 0 || year % 400 == 0)
		{
			cout << "it is aleap yerar";
		}
		else
		{
			cout << "it is not a leap year";
		}

		return 0;

}