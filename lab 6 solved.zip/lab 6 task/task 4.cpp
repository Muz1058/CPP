#include <iostream>
using namespace std;
int main()
{
	float t;
	cout << "Enter the value of temperature in celcius:";
	cin >> t;
	if (t < 0)
	{
		cout << "ICE";
	}
	else if (t >= 0 && t < 100)
	{
		cout << "WATER";
	}
	else
	{
		cout << "STEAM";
	}
	return 0;

}