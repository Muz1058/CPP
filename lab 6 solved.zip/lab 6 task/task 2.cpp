#include <iostream>
using namespace std;
int main()
{
	int num1 ,num2, num3;

	cout << "Enter the value of First number:";
	cin >> num1;
	cout << "Enter the value of Second number:";
	cin >> num2;
	cout << "Enter the value of Third number:";
	cin >> num3;

	if (num1>num2 && num1>num3)
	{
		cout << "First number is greater\n";
	}
	if (num2 > num1 && num2 > num3)
	{
		cout << "Second number is greater\n";
	}
	if (num3 > num1 && num3 >> num2)
	{
		cout << "Third number is greater\n";
	}
	return 0;

}