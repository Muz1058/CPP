#include <iostream>
using namespace std;
int main()
{
	char ch;
	cout << "Enter an alphabat:";
	cin >> ch;
	//for lowercase
	if (ch == 'a' || ch == 'e'|| ch == 'i' || ch == 'o' || ch == 'u' )
	{
		cout << "it is vowel ";
	}
	else if (ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U')
		//for uppercase
	{
		cout << "it is vowel";
	}
	else
	{
		cout << "it is consonent";
	}
	return 0;
}