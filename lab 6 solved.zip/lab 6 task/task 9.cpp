#include <iostream>
using namespace std;
int main()
{
	int num1, num2;
	cout << "Enter value of first number:";
	cin >> num1;

		cout << "Enter value of Second number:";
		cin >> num2;

		if (num1 == num2)
		{
			cout << "both values are same.";
		}

		else
		{
			cout << "both values are not same.";
		}

		return 0;

}