#include <iostream>
using namespace std;
int main()
{
	float phy, totalphy, bio, totalbio, chem, totalchem, math, totalmath, comp, totalcomp, totalobtain, total, div, percentage;

	cout << "Enter total marks of Physics:";
	cin >> totalphy;
	cout << "Enter obtained marks of Physics:";
	cin >> phy;
	cout << "Enter total marks of Biology:";
	cin >> totalbio;
	cout << "Enter obtained marks of Biology:";
	cin >>bio;
	cout << "Enter total marks of Chemistry:";
	cin >>totalchem;
	cout << "Enter obtained marks of Chemistry:";
	cin >> chem;
	cout << "Enter total marks of Mathematics:";
	cin >> totalmath;
	cout << "Enter obtained marks of Mathematics:";
	cin >> math;
	cout << "Enter total marks of Computer:";
	cin >> totalcomp;
	cout << "Enter obtained marks of Computer:";
	cin >> comp;
	//total marks
	total = totalphy + totalbio + totalchem + totalmath + totalcomp;
	cout<<"Total=" << total << endl;
//total obtain marks
	totalobtain = phy + chem + bio + math + comp;
	cout<<"Total marks obtain=" << totalobtain << endl;

	//percentage
	percentage = totalobtain / total * 100;
	cout<<"pencentage=" << percentage << "%\n";
	//grade

	if (percentage >= 90)
	{
	
		cout << "Grade A";
	}

    else if (percentage >= 80)
	{
		cout << "Grade B";
	}
	else if (percentage >= 70)
	{
		cout << "Grade C";
	}

	else if (percentage >= 60)
	{
		cout << "Grade D";
	}
	 else if (percentage >= 40)
	{
		cout << "Grade E";
	}
	else if(percentage<40)
	{
		cout << "Grade F";
	}
	return  0;
}