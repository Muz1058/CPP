#include <iostream>
using namespace std;
int main()
{
	int hour, minute;
	cout << "Enter hours(0-23):";
	cin >> hour ;
	cout << "Enter minutes(0-59):";
	cin >> minute;

	if (hour >= 0 && hour <= 11)
	{
		cout << "It is 'am'";
	}

	 else if (hour >=12 && hour <= 23)
	{
		cout << "It is 'pm'";
	}

	 else
	{
		cout << "invalid input";
	}

	return 0;

}